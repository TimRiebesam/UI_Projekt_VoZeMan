package application.content.roomes;

import javafx.scene.image.Image;

public class Roomes {

	private Image dhPlan;
	private String currentSearch;
	
	public Image getDhPlan() {
		return dhPlan;
	}
	public void setDhPlan(Image dhPlan) {
		this.dhPlan = dhPlan;
	}
	public String getCurrentSearch() {
		return currentSearch;
	}
	public void setCurrentSearch(String currentSearch) {
		this.currentSearch = currentSearch;
	}
	
}
